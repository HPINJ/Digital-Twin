# Streaming Configuration Layers

These `.kit` files, known as `ApplicationLayerTemplates`, are used to define additional functionality added to the base application.

For streaming configuration layers, these templates define and configure the required streaming extensions.

:warning: **Important**: These layers are not standalone application templates. They must be used in conjunction with a base application template.