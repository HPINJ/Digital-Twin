# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.4] - 2024-04-15
- Rename USD Player -> USD Viewer

## [1.0.3] - 2023-12-08
- Fixed deprecation warnings

## [1.0.2] - 2023-12-07
- Renamed to omni.app.usd_player.setup

## [1.0.1] - 2023-12-04
- Updated runtime profiling setings and precache of required extensions.
- Added proper handling of no stage loading mode in splash creen stage state monitoring.

## [1.0.0] - 2021-04-26
- Initial version of extension UI template with a window
