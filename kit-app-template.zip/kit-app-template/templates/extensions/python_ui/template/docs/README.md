# {{ extension_display_name }} [{{ extension_name }}]

A simple python UI extension example. Use it as a starting point for your extensions.
