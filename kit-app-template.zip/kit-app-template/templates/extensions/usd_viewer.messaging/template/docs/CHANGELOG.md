# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).


## [0.1.1] - 2025-02-13
### Removed
- Redundant openedStageResult event dispatch

## [0.1.0] - 2024-04-26
- Initial version of basic python extension template