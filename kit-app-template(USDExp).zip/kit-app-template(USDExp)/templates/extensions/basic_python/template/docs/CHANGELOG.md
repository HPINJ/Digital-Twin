# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).


## [{{ version }}] - {{current_date}}
- Initial version of basic python extension template
