# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).


## [{{ version }}] - 2024-03-13
- Initial version based on kit service extension template
