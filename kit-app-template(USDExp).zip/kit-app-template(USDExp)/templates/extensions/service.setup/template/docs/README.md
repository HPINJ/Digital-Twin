# {{ extension_display_name }} [{{ extension_name }}]

This is an example of a simple Kit Service extension. It is intended to be copied and to serve as a template to create new ones.
