# {{ extension_display_name }} [{{ extension_name }}]

Simple example of an extension that loads a C++ plugin.
